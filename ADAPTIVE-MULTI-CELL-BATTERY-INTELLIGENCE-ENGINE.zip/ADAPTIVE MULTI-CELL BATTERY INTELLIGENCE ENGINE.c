#include <LiquidCrystal.h>

LiquidCrystal lcd(7, 6, 5, 4, 3, 2);

const int cellPins[4] = {A0, A1, A2, A3};

const int greenLED = 8;
const int yellowLED = 9;
const int redLED = 10;
const int buzzer = 11;

float cellVoltage[4];

float avgVoltage;
float maxVoltage;
float minVoltage;

int strongestCell;
int weakestCell;

float imbalance;

String healthState;

void readCells() {

  for (int i = 0; i < 4; i++) {

    int adc = analogRead(cellPins[i]);

    cellVoltage[i] = (adc / 1023.0) * 4.2;
  }
}

void analyzeBattery() {

  float total = 0;

  maxVoltage = cellVoltage[0];
  minVoltage = cellVoltage[0];

  strongestCell = 0;
  weakestCell = 0;

  for (int i = 0; i < 4; i++) {

    total += cellVoltage[i];

    if (cellVoltage[i] > maxVoltage) {
      maxVoltage = cellVoltage[i];
      strongestCell = i;
    }

    if (cellVoltage[i] < minVoltage) {
      minVoltage = cellVoltage[i];
      weakestCell = i;
    }
  }

  avgVoltage = total / 4.0;

  imbalance = ((maxVoltage - minVoltage) / avgVoltage) * 100.0;
}

void classifyHealth() {

  digitalWrite(greenLED, LOW);
  digitalWrite(yellowLED, LOW);
  digitalWrite(redLED, LOW);

  noTone(buzzer);

  if (imbalance <= 2) {

    healthState = "HEALTHY";

    digitalWrite(greenLED, HIGH);
  }

  else if (imbalance <= 5) {

    healthState = "MINOR";

    digitalWrite(yellowLED, HIGH);
  }

  else if (imbalance <= 10) {

    healthState = "CRITICAL";

    digitalWrite(redLED, HIGH);
  }

  else {

    healthState = "FAILURE";

    digitalWrite(redLED, HIGH);

    tone(buzzer, 1000);
  }
}

void updateLCD() {

  lcd.clear();

  lcd.setCursor(0, 0);

  lcd.print("AVG:");
  lcd.print(avgVoltage, 2);

  lcd.setCursor(10, 0);
  lcd.print(healthState);

  lcd.setCursor(0, 1);

  lcd.print("W:");
  lcd.print(weakestCell + 1);

  lcd.print(" S:");
  lcd.print(strongestCell + 1);

  lcd.print(" ");
  lcd.print(imbalance, 1);
  lcd.print("%");
}

void printDashboard() {

  Serial.println("\n================================");

  for (int i = 0; i < 4; i++) {

    Serial.print("Cell ");
    Serial.print(i + 1);

    Serial.print(": ");

    Serial.print(cellVoltage[i], 3);

    Serial.println(" V");
  }

  Serial.println("--------------------------------");

  Serial.print("Average Voltage : ");
  Serial.print(avgVoltage, 3);
  Serial.println(" V");

  Serial.print("Strongest Cell  : Cell ");
  Serial.println(strongestCell + 1);

  Serial.print("Weakest Cell    : Cell ");
  Serial.println(weakestCell + 1);

  Serial.print("Imbalance       : ");
  Serial.print(imbalance, 2);
  Serial.println(" %");

  Serial.print("Health State    : ");
  Serial.println(healthState);

  Serial.println("================================");
}

void setup() {

  Serial.begin(9600);

  lcd.begin(16, 2);

  pinMode(greenLED, OUTPUT);
  pinMode(yellowLED, OUTPUT);
  pinMode(redLED, OUTPUT);

  pinMode(buzzer, OUTPUT);

  lcd.print("Battery Engine");

  delay(2000);
}

void loop() {

  readCells();

  analyzeBattery();

  classifyHealth();

  updateLCD();

  printDashboard();

  delay(2000);
}